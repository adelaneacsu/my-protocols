# This is an auto-generated file. Do not edit it.
from twisted.python import versions
version = versions.Version('twisted.pair', 13, 0, 0)
